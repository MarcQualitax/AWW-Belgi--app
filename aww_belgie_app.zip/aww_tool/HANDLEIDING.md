# Handleiding AWW/KYC Analyse App

## Starten op Windows
Dubbelklik op `start_app_windows.bat`.

## Starten op Mac of Linux
Open Terminal in deze map en voer uit:

```bash
./start_app_mac_linux.sh
```

## Eerste gebruik
1. Download in de app de inputtemplate.
2. Vul ondernemingsnummers aan.
3. Upload het Excel- of CSV-bestand.
4. Klik op **Start analyse**.
5. Download `overzicht.xlsx` of de ZIP met alle rapporten.

## Inputkolommen
Verplicht:

```text
ondernemingsnummer
```

Optioneel:

```text
dossiernummer, klantnaam, dossierbeheerder
```

## Productiegebruik
Voor echte dossiers moet je officiële of contractueel toegelaten databronnen koppelen:

- KBO open data of webservice
- NBB/CBSO of erkende provider
- Belgisch Staatsblad
- sanctie/PEP-provider
- UBO-procedure via mandaat/toegang

De tool is een hulpmiddel voor analyse en documentatie. De eindbeslissing blijft bij het kantoor.
