from __future__ import annotations
from pathlib import Path
from .models import CompanyInput, CompanyReport, SourceRecord
from .validation import is_valid_enterprise_number, normalize_enterprise_number
from .scoring import score_report
from .ai import add_ai_summary
from aww_tool.adapters.kbo import KBOAdapter
from aww_tool.adapters.nbb import NBBAdapter
from aww_tool.adapters.staatsblad import StaatsbladAdapter
from aww_tool.adapters.sanctions import SanctionsAdapter
from aww_tool.adapters.online_search import OnlineSearchAdapter

class AWWPipeline:
    def __init__(self, enable_online_search: bool = True):
        self.enable_online_search = enable_online_search
        self.kbo = KBOAdapter()
        self.nbb = NBBAdapter()
        self.staatsblad = StaatsbladAdapter()
        self.sanctions = SanctionsAdapter()
        self.online = OnlineSearchAdapter()

    def analyse(self, item: CompanyInput, use_ai: bool = True) -> CompanyReport:
        number = normalize_enterprise_number(item.enterprise_number)
        report = CompanyReport(input=item, normalized_number=number)
        if not is_valid_enterprise_number(number):
            report.sources.append(SourceRecord("Validatie", "error", warning="Ongeldig Belgisch ondernemingsnummer."))
            report.risk_level = "Hoog"
            report.total_score = 100
            report.ai_summary = "Ongeldig ondernemingsnummer. Corrigeer de input vooraleer analyse uit te voeren."
            return report

        kbo = self.kbo.fetch(number)
        report.sources.append(kbo)
        if kbo.data:
            data = kbo.data
            report.company_name = data.get("name") or data.get("denomination") or item.klantnaam or "Onbekend"
            report.status = data.get("status") or report.status
            report.legal_form = data.get("legal_form") or report.legal_form
            report.address = data.get("address") or report.address
            report.nace_codes = data.get("nace_codes") or report.nace_codes
            report.directors = data.get("directors") or report.directors
        elif item.klantnaam:
            report.company_name = item.klantnaam

        nbb = self.nbb.fetch(number)
        report.sources.append(nbb)
        report.annual_accounts = nbb.data.get("annual_accounts", []) if nbb.data else []

        staatsblad = self.staatsblad.fetch(number)
        report.sources.append(staatsblad)
        report.publications = staatsblad.data.get("publications", []) if staatsblad.data else []

        sanctions = self.sanctions.fetch(report.company_name, report.directors)
        report.sources.append(sanctions)
        report.sanctions_hits = sanctions.data.get("hits", []) if sanctions.data else []

        if self.enable_online_search:
            online = self.online.fetch(report.company_name, number)
            report.sources.append(online)
            report.online_hits = online.data.get("hits", []) if online.data else []
        else:
            report.sources.append(SourceRecord("Online search", "skipped", warning="Online/adverse-media search uitgeschakeld in de app."))

        score_report(report)
        if use_ai:
            add_ai_summary(report)
        return report
