from __future__ import annotations
from pathlib import Path
from tempfile import NamedTemporaryFile
from datetime import datetime
import zipfile
import shutil
import streamlit as st
from dotenv import load_dotenv

from aww_tool.core.input_loader import load_inputs
from aww_tool.core.pipeline import AWWPipeline
from aww_tool.core.reporting import render_pdf, render_html, write_json, write_overview


def zip_dir(src: Path, dest: Path) -> Path:
    if dest.exists():
        dest.unlink()
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in src.rglob("*"):
            if path.is_file():
                zf.write(path, path.relative_to(src))
    return dest


def clean_dir(path: Path) -> None:
    if path.exists():
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)


def app_info() -> None:
    st.markdown(
        """
        Deze app maakt een AWW/KYC-dossier per Belgisch ondernemingsnummer. Ze is bedoeld als werktool voor een
        accountancykantoor: upload een lijst, start de analyse en download de rapporten.

        **Inputkolommen**
        - verplicht: `ondernemingsnummer`
        - optioneel: `dossiernummer`, `klantnaam`, `dossierbeheerder`

        **Output**
        - een PDF of HTML-rapport per onderneming
        - een JSON auditbestand per onderneming
        - een `overzicht.xlsx` met score en belangrijkste bronstatussen
        - een ZIP met alle resultaten
        """
    )


def make_template_bytes() -> bytes:
    import pandas as pd
    from io import BytesIO

    df = pd.DataFrame(
        [
            {
                "ondernemingsnummer": "0429.053.863",
                "dossiernummer": "DOS-001",
                "klantnaam": "Voorbeeld NV",
                "dossierbeheerder": "Marc",
            },
            {
                "ondernemingsnummer": "0477.472.701",
                "dossiernummer": "DOS-002",
                "klantnaam": "Voorbeeld BV",
                "dossierbeheerder": "Marc",
            },
        ]
    )
    bio = BytesIO()
    df.to_excel(bio, index=False)
    bio.seek(0)
    return bio.read()


def run_analysis(uploaded, use_ai: bool, make_pdf: bool, enable_online: bool) -> None:
    suffix = Path(uploaded.name).suffix.lower()
    with NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(uploaded.getbuffer())
        tmp_path = Path(tmp.name)

    try:
        items = load_inputs(tmp_path)
    except Exception as exc:
        st.error(f"Input kon niet gelezen worden: {exc}")
        return

    if not items:
        st.warning("Geen geldige ondernemingsnummers gevonden.")
        return

    st.success(f"{len(items)} ondernemingsnummers gevonden.")
    preview_rows = [
        {
            "ondernemingsnummer": i.enterprise_number,
            "dossiernummer": i.dossiernummer,
            "klantnaam": i.klantnaam,
            "dossierbeheerder": i.dossierbeheerder,
        }
        for i in items[:25]
    ]
    st.dataframe(preview_rows, use_container_width=True)

    if not st.button("Start analyse", type="primary"):
        return

    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    out = Path("output") / f"aww_run_{run_id}"
    clean_dir(out)

    pipeline = AWWPipeline(enable_online_search=enable_online)
    reports = []
    rows = []

    progress = st.progress(0)
    status = st.empty()
    table_slot = st.empty()

    for idx, item in enumerate(items, start=1):
        status.write(f"Analyse {idx}/{len(items)}: {item.enterprise_number}")
        report = pipeline.analyse(item, use_ai=use_ai)
        reports.append(report)

        if make_pdf:
            render_pdf(report, out)
        else:
            render_html(report, out)
        write_json(report, out)

        rows.append(
            {
                "ondernemingsnummer": report.normalized_number,
                "naam": report.company_name,
                "risicoscore": report.total_score,
                "niveau": report.risk_level,
                "aantal_bevindingen": len(report.risk_factors),
                "bronnen": ", ".join(f"{s.name}:{s.status}" for s in report.sources),
            }
        )
        table_slot.dataframe(rows, use_container_width=True)
        progress.progress(idx / len(items))

    overview = write_overview(reports, out)
    zip_path = out.parent / f"aww_resultaten_{run_id}.zip"
    zip_dir(out, zip_path)

    status.empty()
    st.success("Analyse voltooid.")

    col1, col2 = st.columns(2)
    with col1:
        with open(overview, "rb") as fh:
            st.download_button("Download overzicht.xlsx", fh, file_name="overzicht.xlsx")
    with col2:
        with open(zip_path, "rb") as fh:
            st.download_button("Download alle rapporten", fh, file_name=zip_path.name)


def main() -> None:
    load_dotenv()
    st.set_page_config(page_title="AWW/KYC Analyse App", layout="wide")

    st.title("AWW/KYC Analyse App")
    st.caption("Belgische ondernemingen analyseren voor cliëntenacceptatie en periodieke AWW-controle.")

    with st.sidebar:
        st.header("Instellingen")
        use_ai = st.checkbox("AI-samenvatting gebruiken", value=False)
        make_pdf = st.checkbox("PDF-rapporten genereren", value=True)
        enable_online = st.checkbox("Online/adverse-media adapter gebruiken", value=False)
        st.divider()
        st.download_button(
            "Download inputtemplate.xlsx",
            make_template_bytes(),
            file_name="inputtemplate_aww.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
        st.info("Configureer API-sleutels in `.env` voor echte databronnen. Zonder sleutels werkt de app met beschikbare adapters en mock/fallback-resultaten.")

    tab_upload, tab_handleiding, tab_config = st.tabs(["Analyse", "Handleiding", "Configuratie"])

    with tab_upload:
        uploaded = st.file_uploader("Upload CSV of Excel", type=["csv", "xlsx", "xls"])
        if uploaded:
            run_analysis(uploaded, use_ai=use_ai, make_pdf=make_pdf, enable_online=enable_online)
        else:
            app_info()

    with tab_handleiding:
        st.markdown(
            """
            ### Werkwijze
            1. Maak een Excelbestand met minstens de kolom `ondernemingsnummer`.
            2. Upload het bestand in het tabblad **Analyse**.
            3. Controleer de preview.
            4. Klik op **Start analyse**.
            5. Download het overzicht of alle rapporten als ZIP.

            ### Wat moet je nog manueel of via betaalde bron controleren?
            - UBO-register: enkel via gemachtigde toegang/procedure.
            - PEP- en sanctiescreening: gebruik bij voorkeur een professionele provider.
            - Cliëntenacceptatie: de app geeft indicaties, geen automatische beslissing.
            """
        )

    with tab_config:
        st.code(
            """OPENAI_API_KEY=
KBO_OPEN_DATA_DIR=
KBO_PUBLIC_SEARCH_USERNAME=
KBO_PUBLIC_SEARCH_PASSWORD=
NBB_CBSO_API_KEY=
OPENSANCTIONS_API_KEY=
ONLINE_SEARCH_PROVIDER=disabled
SERPAPI_API_KEY=
BING_SEARCH_API_KEY=
""",
            language="bash",
        )
        st.write("Plaats deze waarden in een bestand `.env` in dezelfde map als `app.py`.")


if __name__ == "__main__":
    main()
