# AWW/KYC Batch Tool voor Belgische ondernemingen

Lokale webtool om honderden ondernemingsnummers te analyseren voor een accountancykantoor.

## Wat doet deze tool?

- Upload Excel/CSV met ondernemingsnummers
- Valideert Belgische ondernemingsnummers
- Zoekt bedrijfsinformatie via bronadapters:
  - KBO/CBE: officiële open data map of Public Search Webservice
  - NBB/CBSO: jaarrekening consultatie/API indien geconfigureerd
  - Belgisch Staatsblad: publicaties rechtspersonen
  - Sancties: OpenSanctions of EU FSF adapter
  - Online/adverse media: optionele zoek-API
- Maakt per onderneming een AWW-risicoanalyse
- Genereert per onderneming een HTML- en PDF-rapport
- Genereert een overzicht.xlsx met score, status en bevindingen

## Belangrijke juridische/technische nota

Deze tool is een hulpmiddel. De eindverantwoordelijkheid voor cliëntenacceptatie, UBO-controle, PEP/sanctie-screening en AWW-dossiervorming blijft bij het kantoor.

Scraping van publieke websites kan technisch of contractueel beperkt zijn. Voor productie wordt sterk aanbevolen om officiële API's, open-databestanden, betaalde dataproviders of expliciete toestemming te gebruiken.

## Installatie

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
```

## Start webtool

```bash
streamlit run app.py
```

Open daarna de URL die Streamlit toont.

## CLI batch

```bash
python -m aww_tool.cli examples/input.csv --output-dir output --pdf
```

## Inputformaat

CSV of Excel met minstens een kolom:

```text
ondernemingsnummer
0123.456.789
0477472701
```

Optionele kolommen:

```text
dossiernummer, klantnaam, dossierbeheerder
```

## Configuratie

Zie `.env.example`.

Belangrijkste variabelen:

- `KBO_OPEN_DATA_DIR`: map met officiële KBO open data CSV-bestanden
- `KBO_PUBLIC_SEARCH_USERNAME` / `KBO_PUBLIC_SEARCH_PASSWORD`: indien Public Search Webservice geactiveerd is
- `NBB_CBSO_API_KEY`: sleutel voor NBB CBSO API, indien beschikbaar
- `OPENSANCTIONS_API_KEY`: sleutel voor OpenSanctions matching
- `OPENAI_API_KEY`: optioneel, voor tekstuele AI-analyse
- `ONLINE_SEARCH_PROVIDER`: `disabled`, `serpapi` of `bing`

## Projectstructuur

```text
aww_tool/
  adapters/        Bronadapters
  core/            Validatie, scoring, rapportmodel
  templates/       HTML templates voor rapporten
  web/             Streamlit UI
app.py             Webtool entrypoint
```

## Productie-aanpassingen die meestal nodig zijn

1. Officiële KBO Webservice of dagelijkse KBO-open-data import configureren.
2. NBB/CBSO API of provider voor jaarrekeningen configureren.
3. UBO-register-proces integreren via mandaat/procedure, niet via publieke scraping.
4. Betrouwbare PEP/sanctie/adverse-media provider kiezen.
5. Dossieropslag, logging en toegangsrechten toevoegen.
6. GDPR/DPIA, verwerkingsregister en retentiebeleid vastleggen.
