from __future__ import annotations
import os
from bs4 import BeautifulSoup
import httpx
from aww_tool.core.models import SourceRecord

class StaatsbladAdapter:
    def __init__(self, base_url: str | None = None):
        self.base_url = base_url or os.getenv("STAATSBLAD_BASE_URL", "https://www.ejustice.just.fgov.be/cgi_tsv_pub/welcome.pl")

    def fetch(self, number: str) -> SourceRecord:
        # Official site query parameters have changed over time. This adapter stores the search URL and parses links best-effort.
        url = f"https://www.ejustice.just.fgov.be/cgi_tsv/tsv_rech.pl?language=nl&btw={number}"
        try:
            resp = httpx.get(url, timeout=25, follow_redirects=True, headers={"User-Agent": "AWW-KYC-tool/1.0"})
            if resp.status_code >= 400:
                return SourceRecord("Belgisch Staatsblad", "error", url=url, warning=f"HTTP {resp.status_code}")
            soup = BeautifulSoup(resp.text, "html.parser")
            publications = []
            for a in soup.find_all("a", href=True)[:50]:
                label = " ".join(a.get_text(" ").split())
                href = a["href"]
                if label or "pdf" in href.lower() or "article" in href.lower():
                    publications.append({"title": label[:250] or href, "url": httpx.URL(url).join(href).__str__()})
            return SourceRecord("Belgisch Staatsblad", "ok", url=url, data={"publications": publications[:25]}, warning="Best-effort parsing. Controleer belangrijke publicaties manueel.")
        except Exception as exc:
            return SourceRecord("Belgisch Staatsblad", "error", url=url, warning=str(exc))
