from __future__ import annotations
from pathlib import Path
import os
import pandas as pd
from bs4 import BeautifulSoup
import httpx
from aww_tool.core.models import SourceRecord
from aww_tool.core.validation import format_enterprise_number

class KBOAdapter:
    """KBO/CBE adapter.

    Preferred production mode: use official KBO open data CSV files downloaded via FPS Economy.
    Fallback mode: best-effort public search page parsing. Public pages can change or block automation.
    """

    def __init__(self, open_data_dir: str | None = None, public_base_url: str | None = None):
        self.open_data_dir = open_data_dir or os.getenv("KBO_OPEN_DATA_DIR")
        self.public_base_url = public_base_url or os.getenv("KBO_PUBLIC_SEARCH_BASE_URL", "https://kbopub.economie.fgov.be/kbopub/zoeknummerform.html")
        self._enterprise_df = None

    def fetch(self, number: str) -> SourceRecord:
        if self.open_data_dir:
            record = self._fetch_from_open_data(number)
            if record.status == "ok":
                return record
        return self._fetch_public_search(number)

    def _fetch_from_open_data(self, number: str) -> SourceRecord:
        try:
            base = Path(self.open_data_dir)
            files = list(base.glob("*enterprise*.csv")) + list(base.glob("*Enterprise*.csv")) + list(base.glob("*.csv"))
            if not files:
                return SourceRecord("KBO Open Data", "warning", warning="Geen CSV-bestanden gevonden in KBO_OPEN_DATA_DIR.")
            if self._enterprise_df is None:
                frames = []
                for f in files[:8]:
                    try:
                        frames.append(pd.read_csv(f, sep=None, engine="python", dtype=str, nrows=300000))
                    except Exception:
                        continue
                self._enterprise_df = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()
            df = self._enterprise_df
            if df.empty:
                return SourceRecord("KBO Open Data", "warning", warning="KBO CSV kon niet gelezen worden.")
            cols = {c.lower(): c for c in df.columns}
            number_col = next((cols[c] for c in cols if c in {"enterprisenumber", "enterprise_number", "ondernemingsnummer", "numeroentreprise"}), None)
            if not number_col:
                return SourceRecord("KBO Open Data", "warning", warning="Geen kolom met ondernemingsnummer gevonden in CSV.")
            cleaned = df[number_col].astype(str).str.replace(r"\D", "", regex=True).str.zfill(10)
            match = df[cleaned == number].head(1)
            if match.empty:
                return SourceRecord("KBO Open Data", "not_found", data={"enterprise_number": number})
            row = match.iloc[0].to_dict()
            return SourceRecord("KBO Open Data", "ok", data=self._map_kbo_row(row))
        except Exception as exc:
            return SourceRecord("KBO Open Data", "error", warning=str(exc))

    def _fetch_public_search(self, number: str) -> SourceRecord:
        url = f"{self.public_base_url}?nummer={number}"
        try:
            with httpx.Client(timeout=20, follow_redirects=True, headers={"User-Agent": "AWW-KYC-tool/1.0"}) as client:
                resp = client.get(url)
            if resp.status_code >= 400:
                return SourceRecord("KBO Public Search", "error", url=url, warning=f"HTTP {resp.status_code}")
            soup = BeautifulSoup(resp.text, "html.parser")
            text = " ".join(soup.get_text(" ").split())
            data = {"enterprise_number": number, "formatted_number": format_enterprise_number(number), "raw_excerpt": text[:4000]}
            # Best effort parsing: keep raw excerpt and try common labels.
            for label, key in [("Naam", "name"), ("Benaming", "name"), ("Status", "status"), ("Rechtsvorm", "legal_form"), ("Adres", "address")]:
                idx = text.lower().find(label.lower())
                if idx >= 0:
                    data[key] = text[idx:idx+180]
            return SourceRecord("KBO Public Search", "ok", url=url, data=data, warning="Best-effort parsing. Gebruik officiële open data/API voor productie.")
        except Exception as exc:
            return SourceRecord("KBO Public Search", "error", url=url, warning=str(exc))

    def _map_kbo_row(self, row: dict) -> dict:
        low = {str(k).lower(): v for k, v in row.items()}
        def pick(*names):
            for n in names:
                if n.lower() in low and pd.notna(low[n.lower()]):
                    return str(low[n.lower()])
            return ""
        return {
            "enterprise_number": pick("EnterpriseNumber", "ondernemingsnummer"),
            "name": pick("Name", "denomination", "benaming", "naam"),
            "status": pick("Status", "statuscode"),
            "legal_form": pick("JuridicalForm", "rechtsvorm", "legalform"),
            "address": pick("Address", "adres"),
            "nace_codes": [v for v in [pick("NaceCode", "NACE", "activitycode")] if v],
            "directors": [],
        }
