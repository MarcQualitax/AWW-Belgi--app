from __future__ import annotations
import os
import httpx
from aww_tool.core.models import SourceRecord

class NBBAdapter:
    def __init__(self, api_base_url: str | None = None, api_key: str | None = None):
        self.api_base_url = api_base_url or os.getenv("NBB_CBSO_API_BASE_URL", "https://api.cbso.nbb.be")
        self.api_key = api_key or os.getenv("NBB_CBSO_API_KEY")

    def fetch(self, number: str) -> SourceRecord:
        consult_url = f"https://consult.cbso.nbb.be/consult-enterprise/{number}"
        if not self.api_key:
            return SourceRecord(
                "NBB Balanscentrale",
                "warning",
                url=consult_url,
                data={"annual_accounts": [], "consult_url": consult_url},
                warning="NBB_CBSO_API_KEY ontbreekt. Rapport bevat consultatielink maar downloadt geen jaarrekening."
            )
        try:
            headers = {"Ocp-Apim-Subscription-Key": self.api_key, "Accept": "application/json"}
            # Endpoint names can differ per subscription product. Keep this isolated for easy adjustment.
            url = f"{self.api_base_url.rstrip('/')}/consult/enterprise/{number}/accounts"
            resp = httpx.get(url, headers=headers, timeout=30)
            if resp.status_code == 404:
                return SourceRecord("NBB Balanscentrale", "not_found", url=consult_url, data={"annual_accounts": []})
            if resp.status_code >= 400:
                return SourceRecord("NBB Balanscentrale", "error", url=url, warning=f"HTTP {resp.status_code}: {resp.text[:500]}")
            payload = resp.json()
            accounts = payload if isinstance(payload, list) else payload.get("items", payload.get("annual_accounts", []))
            return SourceRecord("NBB Balanscentrale", "ok", url=url, data={"annual_accounts": accounts, "consult_url": consult_url})
        except Exception as exc:
            return SourceRecord("NBB Balanscentrale", "error", url=consult_url, warning=str(exc))
