from __future__ import annotations
import os
import httpx
from aww_tool.core.models import SourceRecord

class SanctionsAdapter:
    def __init__(self, api_key: str | None = None, match_url: str | None = None):
        self.api_key = api_key or os.getenv("OPENSANCTIONS_API_KEY")
        self.match_url = match_url or os.getenv("OPENSANCTIONS_MATCH_URL", "https://api.opensanctions.org/match/default")

    def fetch(self, company_name: str, directors: list[dict]) -> SourceRecord:
        subjects = [company_name] + [str(d.get("name", "")) for d in directors if d.get("name")]
        if not self.api_key:
            return SourceRecord("Sanctie/PEP screening", "warning", data={"hits": []}, warning="OPENSANCTIONS_API_KEY ontbreekt. Geen echte sanctiescreening uitgevoerd.")
        hits = []
        try:
            headers = {"Authorization": f"ApiKey {self.api_key}", "Content-Type": "application/json"}
            for subject in subjects:
                if not subject or subject == "Onbekend":
                    continue
                payload = {"queries": {subject: {"schema": "LegalEntity", "properties": {"name": [subject]}}}}
                resp = httpx.post(self.match_url, headers=headers, json=payload, timeout=30)
                if resp.status_code >= 400:
                    hits.append({"subject": subject, "error": f"HTTP {resp.status_code}"})
                    continue
                data = resp.json()
                for result in data.get("responses", {}).get(subject, {}).get("results", []):
                    if result.get("score", 0) >= 0.75:
                        hits.append({"subject": subject, "score": result.get("score"), "caption": result.get("caption"), "id": result.get("id")})
            return SourceRecord("Sanctie/PEP screening", "ok", data={"hits": hits})
        except Exception as exc:
            return SourceRecord("Sanctie/PEP screening", "error", data={"hits": hits}, warning=str(exc))
