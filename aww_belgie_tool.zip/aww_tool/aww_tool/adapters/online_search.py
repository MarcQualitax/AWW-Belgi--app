from __future__ import annotations
import os
import httpx
from aww_tool.core.models import SourceRecord

class OnlineSearchAdapter:
    def __init__(self, provider: str | None = None):
        self.provider = provider or os.getenv("ONLINE_SEARCH_PROVIDER", "disabled")

    def fetch(self, company_name: str, number: str) -> SourceRecord:
        if self.provider == "disabled" or not company_name or company_name == "Onbekend":
            return SourceRecord("Online adverse media", "warning", data={"hits": []}, warning="Online zoeken is uitgeschakeld.")
        query = f'"{company_name}" OR "{number}" fraude faillissement witwassen sanctie'
        if self.provider == "serpapi":
            return self._serpapi(query)
        if self.provider == "bing":
            return self._bing(query)
        return SourceRecord("Online adverse media", "warning", data={"hits": []}, warning=f"Onbekende provider: {self.provider}")

    def _serpapi(self, query: str) -> SourceRecord:
        key = os.getenv("SERPAPI_KEY")
        if not key:
            return SourceRecord("Online adverse media", "warning", data={"hits": []}, warning="SERPAPI_KEY ontbreekt.")
        resp = httpx.get("https://serpapi.com/search.json", params={"engine": "google", "q": query, "api_key": key}, timeout=30)
        data = resp.json()
        hits = [{"title": x.get("title"), "url": x.get("link"), "snippet": x.get("snippet")} for x in data.get("organic_results", [])[:10]]
        return SourceRecord("Online adverse media", "ok", data={"hits": hits, "query": query})

    def _bing(self, query: str) -> SourceRecord:
        key = os.getenv("BING_SEARCH_KEY")
        if not key:
            return SourceRecord("Online adverse media", "warning", data={"hits": []}, warning="BING_SEARCH_KEY ontbreekt.")
        headers = {"Ocp-Apim-Subscription-Key": key}
        resp = httpx.get("https://api.bing.microsoft.com/v7.0/search", params={"q": query}, headers=headers, timeout=30)
        data = resp.json()
        hits = [{"title": x.get("name"), "url": x.get("url"), "snippet": x.get("snippet")} for x in data.get("webPages", {}).get("value", [])[:10]]
        return SourceRecord("Online adverse media", "ok", data={"hits": hits, "query": query})
