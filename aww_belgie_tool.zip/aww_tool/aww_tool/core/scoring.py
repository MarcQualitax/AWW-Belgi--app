from __future__ import annotations
from .models import CompanyReport, RiskFactor

HIGH_RISK_NACE_PREFIXES = {
    "41": "Bouw/promotie kan verhoogd fraude- of onderaannemingsrisico hebben.",
    "42": "Bouw/infrastructuur kan verhoogd risico hebben.",
    "43": "Gespecialiseerde bouwactiviteiten kunnen verhoogd risico hebben.",
    "46": "Groothandel kan verhoogde handels- en goederenstroomrisico's hebben.",
    "47": "Detailhandel met cashgevoelige activiteiten kan verhoogd risico hebben.",
    "55": "Horeca/logies kan cashgevoelig zijn.",
    "56": "Horeca kan cashgevoelig zijn.",
    "64": "Financiële dienstverlening is AWW-gevoelig.",
    "66": "Financiële hulpactiviteiten zijn AWW-gevoelig.",
    "68": "Vastgoedactiviteiten zijn klassiek verhoogd AWW-risico.",
    "92": "Gok- en kansspelactiviteiten zijn verhoogd AWW-risico.",
}

def classify(score: int) -> str:
    if score >= 70:
        return "Hoog"
    if score >= 40:
        return "Middel"
    return "Laag"

def score_report(report: CompanyReport) -> CompanyReport:
    factors: list[RiskFactor] = []

    if report.status.lower() not in {"actief", "active", "actif"} and report.status != "Onbekend":
        factors.append(RiskFactor("STATUS", "Ondernemingsstatus", 25, f"Status is {report.status}."))

    if not report.directors:
        factors.append(RiskFactor("DIR_MISSING", "Bestuurders ontbreken", 15, "Geen bestuurders gevonden in de beschikbare bronnen."))
    elif len(report.directors) > 5:
        factors.append(RiskFactor("DIR_COMPLEX", "Veel bestuurders", 10, "Meer dan vijf bestuurders/mandatarissen gevonden."))

    if not report.ubos and not report.shareholders:
        factors.append(RiskFactor("UBO_MISSING", "UBO/aandeelhouders ontbreken", 20, "Geen UBO- of aandeelhoudersdata beschikbaar. Dit vereist manuele opvolging."))

    for nace in report.nace_codes:
        prefix = ''.join(ch for ch in str(nace) if ch.isdigit())[:2]
        if prefix in HIGH_RISK_NACE_PREFIXES:
            factors.append(RiskFactor("SECTOR_" + prefix, "Sectorrisico", 20, HIGH_RISK_NACE_PREFIXES[prefix]))
            break

    if report.sanctions_hits:
        factors.append(RiskFactor("SANCTIONS", "Sanctie/PEP-hit", 40, "Er is minstens een mogelijke sanctie/PEP-hit. Verificatie vereist."))

    if len(report.publications) >= 8:
        factors.append(RiskFactor("PUB_VOLUME", "Veel Staatsblad-publicaties", 10, "Veel publicaties kunnen wijzen op wijzigingen of complexe historiek."))

    if not report.annual_accounts:
        factors.append(RiskFactor("NBB_MISSING", "Jaarrekening ontbreekt", 10, "Geen jaarrekening gevonden of bron niet geconfigureerd."))

    score = min(100, sum(f.score for f in factors))
    report.risk_factors = factors
    report.total_score = score
    report.risk_level = classify(score)
    report.recommendations = build_recommendations(report)
    return report

def build_recommendations(report: CompanyReport) -> list[str]:
    recs = []
    if not report.ubos and not report.shareholders:
        recs.append("Vraag UBO-registerbewijs of aandeelhoudersstructuur op en documenteer de verificatie.")
    if report.sanctions_hits:
        recs.append("Voer manuele sanctie/PEP-verificatie uit voor elke hit vooraleer het dossier te aanvaarden.")
    if not report.annual_accounts:
        recs.append("Controleer de neerleggingsplicht en vraag recente jaarrekening/financiële informatie op.")
    if report.risk_level == "Hoog":
        recs.append("Laat acceptatie valideren door compliance/verantwoordelijke partner en pas verscherpte waakzaamheid toe.")
    if not recs:
        recs.append("Geen verhoogde signalen op basis van beschikbare bronnen. Standaard cliëntacceptatie kan worden overwogen.")
    return recs
