from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional
from datetime import datetime

@dataclass
class SourceRecord:
    name: str
    status: str
    url: Optional[str] = None
    retrieved_at: str = field(default_factory=lambda: datetime.utcnow().isoformat(timespec="seconds") + "Z")
    data: Dict[str, Any] = field(default_factory=dict)
    warning: Optional[str] = None

@dataclass
class CompanyInput:
    enterprise_number: str
    dossiernummer: Optional[str] = None
    klantnaam: Optional[str] = None
    dossierbeheerder: Optional[str] = None

@dataclass
class RiskFactor:
    code: str
    label: str
    score: int
    explanation: str

@dataclass
class CompanyReport:
    input: CompanyInput
    normalized_number: str
    company_name: str = "Onbekend"
    status: str = "Onbekend"
    legal_form: str = "Onbekend"
    nace_codes: List[str] = field(default_factory=list)
    address: str = "Onbekend"
    directors: List[Dict[str, Any]] = field(default_factory=list)
    shareholders: List[Dict[str, Any]] = field(default_factory=list)
    ubos: List[Dict[str, Any]] = field(default_factory=list)
    publications: List[Dict[str, Any]] = field(default_factory=list)
    annual_accounts: List[Dict[str, Any]] = field(default_factory=list)
    sanctions_hits: List[Dict[str, Any]] = field(default_factory=list)
    online_hits: List[Dict[str, Any]] = field(default_factory=list)
    sources: List[SourceRecord] = field(default_factory=list)
    risk_factors: List[RiskFactor] = field(default_factory=list)
    total_score: int = 0
    risk_level: str = "Onbekend"
    ai_summary: str = ""
    recommendations: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
