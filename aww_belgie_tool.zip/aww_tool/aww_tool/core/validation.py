import re

def normalize_enterprise_number(value: str) -> str:
    digits = re.sub(r"\D", "", str(value or ""))
    if len(digits) == 9:
        digits = "0" + digits
    return digits

def is_valid_enterprise_number(value: str) -> bool:
    digits = normalize_enterprise_number(value)
    if len(digits) != 10 or not digits.isdigit():
        return False
    base = int(digits[:8])
    check = int(digits[8:])
    return (97 - (base % 97)) == check

def format_enterprise_number(value: str) -> str:
    d = normalize_enterprise_number(value)
    if len(d) != 10:
        return value
    return f"{d[:4]}.{d[4:7]}.{d[7:]}"
