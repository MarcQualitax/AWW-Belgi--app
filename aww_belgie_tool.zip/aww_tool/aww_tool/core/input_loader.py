from __future__ import annotations
from pathlib import Path
import pandas as pd
from .models import CompanyInput
from .validation import normalize_enterprise_number, is_valid_enterprise_number

COLUMN_ALIASES = {
    "ondernemingsnummer": "enterprise_number",
    "ondernemingnummer": "enterprise_number",
    "enterprise_number": "enterprise_number",
    "kbo": "enterprise_number",
    "btw": "enterprise_number",
    "vat": "enterprise_number",
    "dossiernummer": "dossiernummer",
    "klantnaam": "klantnaam",
    "dossierbeheerder": "dossierbeheerder",
}

def load_inputs(path: str | Path) -> list[CompanyInput]:
    path = Path(path)
    if path.suffix.lower() in {".xlsx", ".xls"}:
        df = pd.read_excel(path, dtype=str)
    else:
        df = pd.read_csv(path, dtype=str)
    df = df.fillna("")
    df.columns = [COLUMN_ALIASES.get(str(c).strip().lower(), str(c).strip()) for c in df.columns]
    if "enterprise_number" not in df.columns:
        raise ValueError("Input mist kolom 'ondernemingsnummer'.")
    out = []
    for _, row in df.iterrows():
        number = normalize_enterprise_number(row.get("enterprise_number", ""))
        if not is_valid_enterprise_number(number):
            # toch opnemen, zodat rapport fout toont
            pass
        out.append(CompanyInput(
            enterprise_number=number,
            dossiernummer=row.get("dossiernummer") or None,
            klantnaam=row.get("klantnaam") or None,
            dossierbeheerder=row.get("dossierbeheerder") or None,
        ))
    return out
