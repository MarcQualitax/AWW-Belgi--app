from __future__ import annotations
import os
try:
    from openai import OpenAI
except Exception:  # optional dependency
    OpenAI = None
from .models import CompanyReport

SYSTEM_PROMPT = """Je bent een Belgische AWW/KYC compliance assistent voor een accountancykantoor.
Geef een zakelijke, voorzichtige analyse. Verzin geen feiten. Benoem expliciet welke informatie ontbreekt.
De output is geen juridisch advies en moet manueel worden gevalideerd."""

def add_ai_summary(report: CompanyReport) -> CompanyReport:
    if not os.getenv("OPENAI_API_KEY") or OpenAI is None:
        report.ai_summary = fallback_summary(report)
        return report
    client = OpenAI()
    model = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
    payload = report.to_dict()
    try:
        resp = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": f"Maak een beknopte AWW/KYC-analyse in het Nederlands voor dit dossier:\n{payload}"},
            ],
            temperature=0.2,
        )
        report.ai_summary = resp.choices[0].message.content or fallback_summary(report)
    except Exception as exc:
        report.ai_summary = fallback_summary(report) + f"\n\nAI-waarschuwing: {exc}"
    return report

def fallback_summary(report: CompanyReport) -> str:
    missing = []
    if not report.ubos and not report.shareholders:
        missing.append("UBO/aandeelhoudersinformatie")
    if not report.annual_accounts:
        missing.append("jaarrekeninggegevens")
    if not report.directors:
        missing.append("bestuurdersinformatie")
    missing_text = ", ".join(missing) if missing else "geen kerninformatie volgens de tool"
    return (
        f"De onderneming {report.company_name} krijgt een voorlopig AWW-risiconiveau '{report.risk_level}' "
        f"met score {report.total_score}/100. Ontbrekende of te verifiëren informatie: {missing_text}. "
        "Deze conclusie moet manueel worden bevestigd op basis van de originele bronnen en het cliëntacceptatiebeleid van het kantoor."
    )
