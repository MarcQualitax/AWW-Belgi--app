from __future__ import annotations
from pathlib import Path
from datetime import datetime
import json
import pandas as pd
from jinja2 import Environment, FileSystemLoader, select_autoescape
try:
    from weasyprint import HTML
except Exception:  # optional dependency for PDF output
    HTML = None
from .models import CompanyReport
from .validation import format_enterprise_number

TEMPLATE_DIR = Path(__file__).resolve().parents[1] / "templates"

def env() -> Environment:
    return Environment(loader=FileSystemLoader(TEMPLATE_DIR), autoescape=select_autoescape(["html", "xml"]))

def render_html(report: CompanyReport, output_dir: str | Path) -> Path:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    template = env().get_template("report.html")
    html = template.render(report=report, generated_at=datetime.now().strftime("%d/%m/%Y %H:%M"), fmt_num=format_enterprise_number)
    path = output_dir / f"{report.normalized_number}.html"
    path.write_text(html, encoding="utf-8")
    return path

def render_pdf(report: CompanyReport, output_dir: str | Path) -> Path:
    html_path = render_html(report, output_dir)
    pdf_path = Path(output_dir) / f"{report.normalized_number}.pdf"
    if HTML is None:
        raise RuntimeError("WeasyPrint is niet geinstalleerd of kan niet laden. Installeer systeemdependencies of genereer HTML.")
    HTML(filename=str(html_path)).write_pdf(str(pdf_path))
    return pdf_path

def write_json(report: CompanyReport, output_dir: str | Path) -> Path:
    path = Path(output_dir) / f"{report.normalized_number}.json"
    path.write_text(json.dumps(report.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
    return path

def write_overview(reports: list[CompanyReport], output_dir: str | Path) -> Path:
    rows = []
    for r in reports:
        rows.append({
            "ondernemingsnummer": format_enterprise_number(r.normalized_number),
            "naam": r.company_name,
            "status": r.status,
            "rechtsvorm": r.legal_form,
            "risicoscore": r.total_score,
            "risiconiveau": r.risk_level,
            "aantal_bestuurders": len(r.directors),
            "aantal_publicaties": len(r.publications),
            "aantal_jaarrekeningen": len(r.annual_accounts),
            "sanctie_hits": len(r.sanctions_hits),
            "belangrijkste_factoren": "; ".join(f.label for f in r.risk_factors[:5]),
            "aanbevelingen": " | ".join(r.recommendations),
        })
    path = Path(output_dir) / "overzicht.xlsx"
    df = pd.DataFrame(rows)
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Overzicht")
        ws = writer.book["Overzicht"]
        for col in ws.columns:
            max_len = min(60, max(len(str(cell.value or "")) for cell in col) + 2)
            ws.column_dimensions[col[0].column_letter].width = max_len
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions
    return path
