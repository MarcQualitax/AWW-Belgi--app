from __future__ import annotations
import argparse
from pathlib import Path
from dotenv import load_dotenv
from .core.input_loader import load_inputs
from .core.pipeline import AWWPipeline
from .core.reporting import render_pdf, render_html, write_json, write_overview


def main() -> None:
    parser = argparse.ArgumentParser(description="AWW/KYC batchanalyse voor Belgische ondernemingen")
    parser.add_argument("input_file", help="CSV of Excel met ondernemingsnummers")
    parser.add_argument("--output-dir", default="output", help="Outputmap")
    parser.add_argument("--no-ai", action="store_true", help="Geen AI-samenvatting maken")
    parser.add_argument("--pdf", action="store_true", help="PDF rapporten genereren")
    args = parser.parse_args()

    load_dotenv()
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    items = load_inputs(args.input_file)
    pipeline = AWWPipeline()
    reports = []
    for item in items:
        report = pipeline.analyse(item, use_ai=not args.no_ai)
        reports.append(report)
        if args.pdf:
            render_pdf(report, out)
        else:
            render_html(report, out)
        write_json(report, out)
        print(f"{report.normalized_number}: {report.risk_level} {report.total_score}/100 - {report.company_name}")
    overview = write_overview(reports, out)
    print(f"Overzicht: {overview}")

if __name__ == "__main__":
    main()
