from __future__ import annotations
from pathlib import Path
from tempfile import NamedTemporaryFile
import zipfile
import streamlit as st
from dotenv import load_dotenv

from aww_tool.core.input_loader import load_inputs
from aww_tool.core.pipeline import AWWPipeline
from aww_tool.core.reporting import render_pdf, render_html, write_json, write_overview


def zip_dir(src: Path, dest: Path) -> Path:
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in src.rglob("*"):
            if path.is_file():
                zf.write(path, path.relative_to(src))
    return dest


def main() -> None:
    load_dotenv()
    st.set_page_config(page_title="AWW/KYC Batch Tool", layout="wide")
    st.title("AWW/KYC Batch Tool voor Belgische ondernemingen")
    st.caption("Upload een Excel/CSV met ondernemingsnummers en genereer per onderneming een rapport.")

    with st.sidebar:
        st.header("Instellingen")
        use_ai = st.checkbox("AI-samenvatting gebruiken", value=True)
        make_pdf = st.checkbox("PDF rapporten genereren", value=True)
        st.info("Voor productie: configureer KBO, NBB, sanctie- en zoek-API's in het .env-bestand.")

    uploaded = st.file_uploader("Upload CSV of Excel", type=["csv", "xlsx", "xls"])
    if not uploaded:
        st.write("Verwachte kolom: `ondernemingsnummer`. Optioneel: `dossiernummer`, `klantnaam`, `dossierbeheerder`.")
        return

    suffix = Path(uploaded.name).suffix
    with NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(uploaded.getbuffer())
        tmp_path = Path(tmp.name)

    try:
        items = load_inputs(tmp_path)
    except Exception as exc:
        st.error(f"Input kon niet gelezen worden: {exc}")
        return

    st.success(f"{len(items)} ondernemingsnummers gevonden.")
    if st.button("Start analyse", type="primary"):
        out = Path("output") / "streamlit_run"
        if out.exists():
            for p in out.rglob("*"):
                if p.is_file():
                    p.unlink()
        out.mkdir(parents=True, exist_ok=True)

        pipeline = AWWPipeline()
        reports = []
        progress = st.progress(0)
        table_slot = st.empty()
        rows = []
        for idx, item in enumerate(items, start=1):
            report = pipeline.analyse(item, use_ai=use_ai)
            reports.append(report)
            if make_pdf:
                render_pdf(report, out)
            else:
                render_html(report, out)
            write_json(report, out)
            rows.append({
                "ondernemingsnummer": report.normalized_number,
                "naam": report.company_name,
                "score": report.total_score,
                "niveau": report.risk_level,
                "bronnen": ", ".join(f"{s.name}:{s.status}" for s in report.sources),
            })
            table_slot.dataframe(rows, use_container_width=True)
            progress.progress(idx / len(items))

        overview = write_overview(reports, out)
        zip_path = out.parent / "aww_resultaten.zip"
        zip_dir(out, zip_path)
        st.success("Analyse voltooid.")
        with open(overview, "rb") as fh:
            st.download_button("Download overzicht.xlsx", fh, file_name="overzicht.xlsx")
        with open(zip_path, "rb") as fh:
            st.download_button("Download alle rapporten ZIP", fh, file_name="aww_resultaten.zip")
